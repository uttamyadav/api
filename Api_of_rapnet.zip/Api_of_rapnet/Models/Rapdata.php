<?php 
	function getItems($conn)
	{	
		$sql = "SELECT * FROM rapdata";

		$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));

		$data = array();

		while( $rows = mysqli_fetch_assoc($resultset) )
		{
			$data[] = $rows;
		}
		return $data;
	}
?>