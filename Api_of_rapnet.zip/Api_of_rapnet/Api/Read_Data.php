<?php
include_once("../Database/Database_Connection.php");
include_once("../Models/Rapdata.php");

	if($_SERVER["REQUEST_METHOD"] == "GET")
	{
		$items = getItems($conn);	
		if(empty($items))
		{
			jsonResponse(200,"Items Not Found",NULL);
		}
		else
		{
			jsonResponse(200,"Item Found",$items);
		}	
	}
	else
	{
		jsonResponse(400,"Invalid Request",NULL);
	}

	function jsonResponse($status,$status_message,$data)
	{
		header("Access-Control-Allow-Origin: *");
		
		header("Content-Type: application/json; charset=UTF-8");
		
		header("Access-Control-Allow-Methods: POST");
		
		header("Access-Control-Max-Age: 3600");
		
		header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
		header("Content-Type:application/json");
		
		header("HTTP/1.1 ".$status_message);	
		
		$response['status']=$status;
		
		$response['status_message']=$status_message;
		
		$response['data']=$data;	
		
		$json_response = json_encode($response);
		
		echo $json_response;
	}           

	
?>